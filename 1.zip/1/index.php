<?php

/*

			1#

			>>>XAAMP  (Appache + MYSq => Enable)      Port problem: Ukoliko Appache ili MySql ne može da se aktivira potrebno je iskljuciti Skype ili njemu sličan program. Razlog je taj što po default-u  programi koriste isto port 80 i on ga blokira!


			>>>Gde se nalazi PHP direktorijum?      C/xampp/htdocs (VSC)      Razlika izmedju htmla-a je što se php ne može otvoriti standardno preko browsera. 

			>>>Otvaranje projekta  => Unutar adress bar u browseru				 localhost/#projekat	

			>>> Ukoliko ispisujemo samo php unutar index.php zatvaranje taga ?> nije neophodno. Razlika izmedju html i php dokumenta je što u index.html možemo unositi samo html, dok index.php može sadrži i html i css i php.

			>>> Otvaranje php taga - ukoliko 		<?php        ?>

			>>> String (string)		 integer (int) 			decimal (float) 					boolean (bool)       	     = Data types

			>>> string => "Neki tekst "       int => 20,21,45,1123 - celi brojevi           float => 20.5, 3.5, 7.1 - brojevi sa decimalnom tackom          bool => (true/false)     

			>>>String ili sve sto je tekst uvek ide pod znakovima navodnika. Dok integer ili brojevi idu bez znakova navodnika npr        
                    	                                                                                                          "marka" => "Audi"       
                                                                                                                                  "model" =>  "A4"            
                                                                                                                                  "godiste" => 2015

			>>>Echo (Ispiši - Prikaži)  ispisuje odredjenu vrednost varijable i ispisuje se bez znaka "="			         echo $automobili[2] ;       echo $osobe[2]; 
			>>>Error Reporting ( Notice , Warning , Error )  	 	
								Notice => Postoji greška, bilo bi dobro da je popravite - kod nastavlja da radi
								Warning => Isto što i notice
								Error => blokira kod i baca grešku !!!

                                
			>>>Kako nikada ne pisati varijable!!! 
			>>> append (dodavanje na varijablu)

			>>>PHP Komentar			// single-line comment  	# also a single-line comment		/* multi-line comment */



$ime = "Ognjen";
$prezime = "Topic";
$godiste = "1998";
$visina = 190;
$trenutna_godina = date("Y"); 
$godine = $trenutna_godina-$godiste;

echo "Moje ime je $ime $prezime, imam $godine godina i visok sam $visina cm";






$cena = 145000;
$iznos_poreza = 0.22;
$porez = $cena*$iznos_poreza;
$total_cena = $cena+$porez;

echo "Cena ovog televizora bez pdv-a iznosi $cena dinara. Iznos poreza: $porez ($iznos_poreza %). Ukupna cena proizvoda sa pdv-om iznosi $total_cena dinara";

?>